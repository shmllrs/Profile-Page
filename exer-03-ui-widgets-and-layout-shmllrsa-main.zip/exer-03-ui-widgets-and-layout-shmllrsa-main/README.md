# Exercise 3 - CMSC 23

**Name:** Shamel Larosa <br/>
**Section:** UV-3L <br/>
**Student number:** 2023-06239 <br/>

## Code Description
This program is a profile page wherein it shows the posts, followers, following, how many posts, and a profile picture. User can add posts through an icon in the lower right side, a + icon.

## Challenges encountered
I had troubles with aligning the icons and the texts (posts, reels, saved, tagged). It was so hard that I had to search for other resources online like YouTube videos and other platforms that has similar existing problems.

## Solutions
I saw a website where it uses .map and "tab" to align the icons and texts properly. The tab when clicked will change to another page but no implementations yet. It uses .map for the children to specify which tab will show when selected, it also uses if-else which in children is "?".

## References
- https://docs.flutter.dev/cookbook/lists/basic-list
- https://www.geeksforgeeks.org/flutter-tabs/
- https://stackoverflow.com/questions/53908405/how-to-add-a-new-pair-to-map-in-dart
- https://api.flutter.dev/flutter/material/Icons-class.html
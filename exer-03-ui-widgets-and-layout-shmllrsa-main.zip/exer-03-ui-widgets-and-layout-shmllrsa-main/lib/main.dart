import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    //header
    return MaterialApp(
      //not to show yung debug flag sa right corner
      debugShowCheckedModeBanner: false,
      title: 'Profile Page',
      //header color
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.purple),
        useMaterial3: true,
      ),
      //username
      home: const MyHomePage(title: "@Kuromi 𓈒ׂ 𝜗𝜚"),
    );
  }
}

class MyHomePage extends StatefulWidget {
  //gets title basta yung kuromi
  const MyHomePage({super.key, required this.title});
  //store rito
  final String title;

  @override
  //store ng data ng widget (implementations)
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  //list ng images
  //instead na sa pubspec, dito nalang ni-list then sa pubspec -assets/ nalang dinagdag
  List<String> images = [
    'assets/1.jpg',
    'assets/2.jpg',
    'assets/3.jpg',
    'assets/4.jpg',
    'assets/5.jpg',
    'assets/6.jpg',
  ];

  //store posts in a lists
  List<String> posts = [];
  //tracking ng selected tabs
  String selectedTab = 'Posts';

  @override
  void initState() {
    //calls _myhomepagestate para mag-initialize yung implementations
    super.initState();
    //adds images
    posts.addAll(images);
  }

  void addPost() {
    //add posts
    /* pagpinindot yung plus then yung list of images maglo-loop to post pics
    then if wala ng bago sa list of pics then babalik ulit para ipost yung nasa
    unahan ng list na pics */
    setState(() {
      posts.add(images[posts.length % images.length]);
    });
  }

  @override
  Widget build(BuildContext context) {
    //header
    return Scaffold(
      appBar: AppBar(
        //compliment the colors
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Align(
          alignment: Alignment.centerLeft,
          child: Text(widget.title),
        ),
      ),
      //body
      body: Column(
        children: [
          Container(
            //layout
            padding: const EdgeInsets.all(16.0),
            child: Column(
              //align data vertically
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    //use clipoval for profile
                    ClipOval(
                      //for profile pic
                      child: Image.asset(
                        'assets/profile.jpg',
                        width: 80,
                        height: 80,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        //alignment for header contents
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            //align kuromi text (right) and add bio (left)
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              //for kuromi
                              const Text(
                                'Kuromi',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              //add bio
                              TextButton(
                                //can be clicked pero no changes (no implementation)
                                onPressed: () {},
                                child: const Text(
                                  'Add Bio',
                                  style: TextStyle(color: Colors.blue),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Row(
                            //align the three in lined alignment
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('${posts.length} Posts '),
                              const Text('1 Following  '),
                              const Text('1M Followers'),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Row(
            //icons
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //reference: https://www.geeksforgeeks.org/flutter-tabs/
            //each tab has contents (since reels, saved and tagged walang implementation then sho-show lang ng text)
            children: [
              {'tab': 'Posts', 'icon': Icons.image},
              {'tab': 'Reels', 'icon': Icons.movie},
              {'tab': 'Saved', 'icon': Icons.bookmark},
              {'tab': 'Tagged', 'icon': Icons.person},
            ].map((data) {
              //when selected each tab
              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedTab = data['tab'] as String;
                  });
                },
                child: Column(
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        //for the alignment of icons
                        Icon(
                          data['icon'] as IconData,
                          color: selectedTab == data['tab'] ? Colors.purple : Colors.black,
                        ),
                        const SizedBox(width: 5),
                        //alignment of texts (posts, reels, tagged, and saved)
                        Text(
                          data['tab'] as String,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: selectedTab == data['tab'] ? Colors.purple : Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 10),
          Expanded(
            //when selected posts
            //if its the post being selected then it shows the pictures
            child: selectedTab == 'Posts'
                ? GridView.builder(
                    padding: const EdgeInsets.all(8.0),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      //number of columns
                      crossAxisCount: 3,
                      //spacing columns
                      crossAxisSpacing: 4,
                      //spacing columns
                      mainAxisSpacing: 4,
                    ),
                    //total number ng idi-display na pics
                    itemCount: posts.length,
                    //susundin structure ng grid
                    itemBuilder: (context, index) {
                      //pictures to fit
                      return Image.asset(posts[index], fit: BoxFit.cover);
                    },
                  )
                  //if its not then it shows this
                : Center(
                    child: Text(
                      'No images to show',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
          ),
        ],
      ),
      //for adding pictures (+ icon)
      floatingActionButton: FloatingActionButton(
        onPressed: addPost,
        tooltip: 'Add Post',
        child: const Icon(Icons.add),
      ),
    );
  }
}
